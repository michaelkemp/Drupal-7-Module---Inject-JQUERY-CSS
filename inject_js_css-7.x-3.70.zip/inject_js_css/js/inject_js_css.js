(function ($) { jQuery(document).ready(function($) {
    $("#edit-submit").addClass("btn btn-primary");
    $("#edit-jquerypages-fieldset-insert-page").addClass("btn btn-success");
}); }(jQuery));